# Rosetta — Translator App

A desktop translation app built with Python and Tkinter. Enter text, pick a
source and target language, and get a translation back on screen — with
copy-to-clipboard and text-to-speech built in.

## Features

- Text input box with a live character counter
- Source & target language dropdowns (35 languages) with a swap button
- Sends text to a translation API and displays the result clearly
- Copy button (clipboard)
- Listen button (offline text-to-speech, both source and translated text)
- Runs the API call on a background thread so the window never freezes
- Pluggable translation provider: MyMemory (free, default), Google Cloud
  Translation API, or Microsoft Translator — swap with one setting, no code
  changes needed

## Project structure

```
rosetta_project/
├── main.py              # entry point — run this
├── gui.py                # Tkinter interface
├── translator_api.py      # translation provider logic (MyMemory / Google / Microsoft)
├── languages.py           # shared list of supported languages
├── requirements.txt
├── .env.example           # copy to .env and fill in API keys if using Google/Microsoft
└── README.md
```

## Setup

1. Install Python 3.9+.
2. Install dependencies:

   ```bash
   pip install -r requirements.txt
   ```

3. Run the app:

   ```bash
   python main.py
   ```

That's it — by default the app uses the **MyMemory** API, which is free and
needs no key, so it works right away as long as you have an internet
connection.

## Switching to Google Translate or Microsoft Translator

The app is built so you can drop in a real commercial API without touching
the interface code.

### Option A — Google Cloud Translation API

1. Create a project in Google Cloud Console and enable the **Cloud
   Translation API**.
2. Generate an API key.
3. Set it as an environment variable:

   ```bash
   export GOOGLE_TRANSLATE_API_KEY=your_key_here      # macOS/Linux
   setx GOOGLE_TRANSLATE_API_KEY "your_key_here"       # Windows
   ```

4. Run with:

   ```bash
   python main.py --provider google
   ```

### Option B — Microsoft Translator (Azure)

1. Create a **Translator** resource in the Azure portal.
2. Grab its API key and region from the resource's "Keys and Endpoint" page.
3. Set them as environment variables:

   ```bash
   export MICROSOFT_TRANSLATOR_KEY=your_key_here
   export MICROSOFT_TRANSLATOR_REGION=your_region_here
   ```

4. Run with:

   ```bash
   python main.py --provider microsoft
   ```

You can also set `TRANSLATION_PROVIDER=google` (or `microsoft`) as an
environment variable instead of passing `--provider` every time — see
`.env.example`.

## Notes

- `pyttsx3` (text-to-speech) and `pyperclip` (clipboard) are optional. If
  they aren't installed, the app still runs — Listen will show a short
  message telling you how to enable it, and Copy falls back to Tkinter's
  built-in clipboard.
- The MyMemory free tier caps requests around 500 characters and has a
  daily usage limit. Google and Microsoft are paid APIs (each with a free
  monthly quota) meant for heavier or production use.
