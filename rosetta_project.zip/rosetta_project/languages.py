"""
languages.py
------------
Shared list of supported languages, as (code, display_name) pairs.
Codes follow ISO 639-1 and work with MyMemory, Google Translate, and
Microsoft Translator alike.
"""

LANGUAGES = [
    ("en", "English"), ("es", "Spanish"), ("fr", "French"), ("de", "German"),
    ("it", "Italian"), ("pt", "Portuguese"), ("nl", "Dutch"), ("ru", "Russian"),
    ("ja", "Japanese"), ("ko", "Korean"), ("zh", "Chinese (Simplified)"),
    ("ar", "Arabic"), ("hi", "Hindi"), ("ur", "Urdu"), ("bn", "Bengali"),
    ("tr", "Turkish"), ("vi", "Vietnamese"), ("th", "Thai"), ("id", "Indonesian"),
    ("pl", "Polish"), ("sv", "Swedish"), ("fi", "Finnish"), ("no", "Norwegian"),
    ("da", "Danish"), ("el", "Greek"), ("he", "Hebrew"), ("cs", "Czech"),
    ("ro", "Romanian"), ("hu", "Hungarian"), ("uk", "Ukrainian"), ("fa", "Persian"),
    ("ms", "Malay"), ("sw", "Swahili"), ("ta", "Tamil"), ("te", "Telugu"),
    ("pa", "Punjabi"),
]

CODE_TO_NAME = dict(LANGUAGES)
NAME_TO_CODE = {name: code for code, name in LANGUAGES}
NAMES = [name for _, name in LANGUAGES]
