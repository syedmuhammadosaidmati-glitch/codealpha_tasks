"""
gui.py
------
The Tkinter user interface for Rosetta. Imports translation logic from
translator_api.py and the language list from languages.py, so the
interface itself has no API-specific code in it.
"""

import threading
import tkinter as tk
from tkinter import ttk, messagebox

from languages import NAMES, NAME_TO_CODE
from translator_api import get_translator, TranslationError

try:
    import pyperclip
    HAS_PYPERCLIP = True
except ImportError:
    HAS_PYPERCLIP = False

try:
    import pyttsx3
    HAS_PYTTSX3 = True
except ImportError:
    HAS_PYTTSX3 = False


# ---------------------------------------------------------------------
# Color palette
# ---------------------------------------------------------------------
INK_950 = "#14171f"
INK_800 = "#1e2330"
INK_700 = "#2a3142"
PARCHMENT_100 = "#f1ead9"
GOLD_500 = "#c9a24b"
GOLD_400 = "#dab868"
SLATE_400 = "#8890a0"
DANGER = "#d9714f"


class RosettaApp(tk.Tk):
    def __init__(self, provider: str = None):
        super().__init__()
        self.title("Rosetta — Translate")
        self.geometry("880x560")
        self.minsize(680, 480)
        self.configure(bg=INK_950)

        self.last_translation = ""

        # The translator is chosen once at startup (mymemory / google / microsoft).
        # See translator_api.get_translator() and README.md for how to switch.
        try:
            self.translator = get_translator(provider)
        except TranslationError as e:
            messagebox.showerror("Setup error", str(e))
            raise SystemExit(1)

        self._build_styles()
        self._build_ui()

    # -----------------------------------------------------------------
    def _build_styles(self):
        style = ttk.Style(self)
        style.theme_use("clam")

        style.configure(
            "TCombobox", fieldbackground=INK_800, background=INK_800,
            foreground=PARCHMENT_100, arrowcolor=SLATE_400,
            bordercolor=INK_700, lightcolor=INK_800, darkcolor=INK_800, padding=6,
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", INK_800)],
            foreground=[("readonly", PARCHMENT_100)],
        )

        style.configure(
            "Gold.TButton", background=GOLD_500, foreground=INK_950,
            font=("Segoe UI", 11, "bold"), padding=(20, 10), borderwidth=0,
        )
        style.map("Gold.TButton", background=[("active", GOLD_400)])

        style.configure(
            "Ghost.TButton", background=INK_800, foreground=SLATE_400,
            font=("Segoe UI", 9), padding=(10, 6), borderwidth=1,
        )
        style.map(
            "Ghost.TButton",
            background=[("active", INK_700)],
            foreground=[("active", PARCHMENT_100)],
        )

        style.configure(
            "Swap.TButton", background=INK_800, foreground=GOLD_400,
            font=("Segoe UI", 12, "bold"), padding=6, borderwidth=1,
        )
        style.map("Swap.TButton", background=[("active", INK_700)])

    # -----------------------------------------------------------------
    def _build_ui(self):
        header = tk.Frame(self, bg=INK_950)
        header.pack(fill="x", pady=(24, 12), padx=24)
        tk.Label(
            header, text="A SMALL BRIDGE BETWEEN LANGUAGES",
            bg=INK_950, fg=GOLD_400, font=("Consolas", 9, "bold"),
        ).pack()
        tk.Label(
            header, text="Rosetta", bg=INK_950, fg=PARCHMENT_100,
            font=("Georgia", 26, "bold"),
        ).pack(pady=(4, 0))

        lang_row = tk.Frame(self, bg=INK_950)
        lang_row.pack(fill="x", padx=24, pady=(4, 16))
        lang_row.columnconfigure(0, weight=1)
        lang_row.columnconfigure(2, weight=1)

        self.source_var = tk.StringVar(value="English")
        self.target_var = tk.StringVar(value="Spanish")

        self.source_combo = ttk.Combobox(
            lang_row, textvariable=self.source_var, values=NAMES, state="readonly",
        )
        self.source_combo.grid(row=0, column=0, sticky="ew", padx=(0, 10))

        ttk.Button(
            lang_row, text="⇄", style="Swap.TButton", width=3,
            command=self.swap_languages,
        ).grid(row=0, column=1)

        self.target_combo = ttk.Combobox(
            lang_row, textvariable=self.target_var, values=NAMES, state="readonly",
        )
        self.target_combo.grid(row=0, column=2, sticky="ew", padx=(10, 0))

        panels = tk.Frame(self, bg=INK_950)
        panels.pack(fill="both", expand=True, padx=24)
        panels.columnconfigure(0, weight=1)
        panels.columnconfigure(1, weight=1)
        panels.rowconfigure(0, weight=1)

        # Source panel
        source_panel = tk.Frame(panels, bg=INK_800)
        source_panel.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        tk.Label(
            source_panel, text="SOURCE", bg=INK_800, fg=SLATE_400,
            font=("Consolas", 8, "bold"),
        ).pack(anchor="w", padx=14, pady=(12, 4))

        self.source_text = tk.Text(
            source_panel, wrap="word", bg=INK_800, fg=PARCHMENT_100,
            insertbackground=PARCHMENT_100, relief="flat",
            font=("Segoe UI", 12), padx=14, pady=6, height=10,
        )
        self.source_text.pack(fill="both", expand=True, padx=4)
        self.source_text.bind("<KeyRelease>", self.update_char_count)
        self.source_text.bind("<Control-Return>", lambda e: self.translate())

        source_footer = tk.Frame(source_panel, bg=INK_800)
        source_footer.pack(fill="x", padx=10, pady=8)
        self.char_count_label = tk.Label(
            source_footer, text="0 / 490", bg=INK_800, fg=SLATE_400, font=("Consolas", 9),
        )
        self.char_count_label.pack(side="left")

        btns = tk.Frame(source_footer, bg=INK_800)
        btns.pack(side="right")
        ttk.Button(
            btns, text="Clear", style="Ghost.TButton", command=self.clear_text
        ).pack(side="left", padx=2)
        ttk.Button(
            btns, text="🔊 Listen", style="Ghost.TButton",
            command=lambda: self.speak(self.source_text.get("1.0", "end").strip(), self.source_var.get()),
        ).pack(side="left", padx=2)

        # Output panel
        output_panel = tk.Frame(panels, bg=INK_800)
        output_panel.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        tk.Label(
            output_panel, text="TRANSLATION", bg=INK_800, fg=SLATE_400,
            font=("Consolas", 8, "bold"),
        ).pack(anchor="w", padx=14, pady=(12, 4))

        self.output_text = tk.Text(
            output_panel, wrap="word", bg=INK_800, fg=SLATE_400, relief="flat",
            font=("Segoe UI", 12), padx=14, pady=6, height=10, state="disabled",
        )
        self.output_text.pack(fill="both", expand=True, padx=4)
        self._set_output("Your translation will appear here.", muted=True)

        output_footer = tk.Frame(output_panel, bg=INK_800)
        output_footer.pack(fill="x", padx=10, pady=8)
        self.output_count_label = tk.Label(
            output_footer, text="", bg=INK_800, fg=SLATE_400, font=("Consolas", 9),
        )
        self.output_count_label.pack(side="left")

        out_btns = tk.Frame(output_footer, bg=INK_800)
        out_btns.pack(side="right")
        self.copy_btn = ttk.Button(
            out_btns, text="📋 Copy", style="Ghost.TButton",
            command=self.copy_translation, state="disabled",
        )
        self.copy_btn.pack(side="left", padx=2)
        self.listen_out_btn = ttk.Button(
            out_btns, text="🔊 Listen", style="Ghost.TButton",
            command=lambda: self.speak(self.last_translation, self.target_var.get()),
            state="disabled",
        )
        self.listen_out_btn.pack(side="left", padx=2)

        # Translate button
        action_row = tk.Frame(self, bg=INK_950)
        action_row.pack(pady=20)
        self.translate_btn = ttk.Button(
            action_row, text="Translate", style="Gold.TButton", command=self.translate,
        )
        self.translate_btn.pack()

        tk.Label(
            self, text="Press Ctrl + Enter to translate  •  click in the source box first",
            bg=INK_950, fg=SLATE_400, font=("Consolas", 9),
        ).pack(pady=(0, 4))

        provider_name = type(self.translator).__name__
        tk.Label(
            self, text=f"Provider: {provider_name}",
            bg=INK_950, fg=SLATE_400, font=("Consolas", 8),
        ).pack(pady=(0, 12))

    # -----------------------------------------------------------------
    def update_char_count(self, event=None):
        text = self.source_text.get("1.0", "end-1c")
        if len(text) > 490:
            text = text[:490]
            self.source_text.delete("1.0", "end")
            self.source_text.insert("1.0", text)
        n = len(text)
        self.char_count_label.config(text=f"{n} / 490", fg=GOLD_400 if n > 440 else SLATE_400)

    def clear_text(self):
        self.source_text.delete("1.0", "end")
        self.update_char_count()
        self.source_text.focus_set()

    def _set_output(self, text, muted=False, error=False):
        self.output_text.config(state="normal")
        self.output_text.delete("1.0", "end")
        self.output_text.insert("1.0", text)
        color = SLATE_400 if muted else (DANGER if error else PARCHMENT_100)
        self.output_text.config(fg=color, state="disabled")

    def swap_languages(self):
        s, t = self.source_var.get(), self.target_var.get()
        self.source_var.set(t)
        self.target_var.set(s)
        if self.last_translation:
            self.source_text.delete("1.0", "end")
            self.source_text.insert("1.0", self.last_translation)
            self.update_char_count()

    def copy_translation(self):
        if not self.last_translation:
            return
        try:
            if HAS_PYPERCLIP:
                pyperclip.copy(self.last_translation)
            else:
                self.clipboard_clear()
                self.clipboard_append(self.last_translation)
            original = self.copy_btn["text"]
            self.copy_btn.config(text="✓ Copied")
            self.after(1600, lambda: self.copy_btn.config(text=original))
        except Exception:
            messagebox.showwarning("Copy failed", "Couldn't access the clipboard.")

    def speak(self, text, lang_name):
        if not text:
            return
        if not HAS_PYTTSX3:
            messagebox.showinfo(
                "Text-to-speech unavailable",
                "Install pyttsx3 to enable this feature:\n\npip install pyttsx3",
            )
            return

        def _run():
            try:
                engine = pyttsx3.init()
                engine.say(text)
                engine.runAndWait()
            except Exception:
                pass

        threading.Thread(target=_run, daemon=True).start()

    # -----------------------------------------------------------------
    def translate(self):
        text = self.source_text.get("1.0", "end").strip()
        if not text:
            self.source_text.focus_set()
            return

        from_code = NAME_TO_CODE[self.source_var.get()]
        to_code = NAME_TO_CODE[self.target_var.get()]

        if from_code == to_code:
            self._on_success(text)
            return

        self.translate_btn.config(state="disabled", text="Translating…")

        def _run():
            try:
                result = self.translator.translate(text, from_code, to_code)
                self.after(0, self._on_success, result)
            except TranslationError as e:
                self.after(0, self._on_error, str(e))
            except Exception as e:
                self.after(0, self._on_error, f"Unexpected error: {e}")

        threading.Thread(target=_run, daemon=True).start()

    def _on_success(self, translated):
        self.last_translation = translated
        self._set_output(translated)
        self.output_count_label.config(text=f"{len(translated)} chars")
        self.copy_btn.config(state="normal")
        self.listen_out_btn.config(state="normal")
        self.translate_btn.config(state="normal", text="Translate")

    def _on_error(self, message="Couldn't reach the translation service. Check your internet connection and try again."):
        self.last_translation = ""
        self._set_output(message, error=True)
        self.output_count_label.config(text="")
        self.copy_btn.config(state="disabled")
        self.listen_out_btn.config(state="disabled")
        self.translate_btn.config(state="normal", text="Translate")
