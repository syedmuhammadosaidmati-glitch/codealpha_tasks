"""
main.py
-------
Entry point for the Rosetta translator app.

Run with:
    python main.py

Optionally choose a provider without editing code:
    python main.py --provider google
    python main.py --provider microsoft
    python main.py --provider mymemory   (default)

Provider credentials are read from environment variables — see README.md.
"""

import argparse
from gui import RosettaApp


def main():
    parser = argparse.ArgumentParser(description="Rosetta — desktop translator")
    parser.add_argument(
        "--provider",
        choices=["mymemory", "google", "microsoft"],
        default=None,
        help="Translation provider to use (defaults to TRANSLATION_PROVIDER env var, or mymemory).",
    )
    args = parser.parse_args()

    app = RosettaApp(provider=args.provider)
    app.mainloop()


if __name__ == "__main__":
    main()
