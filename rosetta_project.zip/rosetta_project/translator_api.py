"""
translator_api.py
------------------
Handles all communication with translation APIs.

Three providers are implemented behind one common interface:

    1. MyMemoryTranslator      -> free, no API key, used by default
    2. GoogleTranslateAPI      -> Google Cloud Translation API (needs an API key)
    3. MicrosoftTranslatorAPI  -> Microsoft Translator (Azure Cognitive Services, needs a key)

Switch providers by setting the TRANSLATION_PROVIDER environment variable to
"mymemory", "google", or "microsoft" (see README.md for setup instructions).

Every provider class exposes the same method:

    translate(text: str, source_lang: str, target_lang: str) -> str

so the GUI code never needs to know which provider is active.
"""

import os
import uuid
import requests


class TranslationError(Exception):
    """Raised when a translation request fails for any reason."""
    pass


# ---------------------------------------------------------------------
# 1. MyMemory — free, no key required. Good default / fallback.
# ---------------------------------------------------------------------
class MyMemoryTranslator:
    BASE_URL = "https://api.mymemory.translated.net/get"

    def translate(self, text: str, source_lang: str, target_lang: str) -> str:
        params = {"q": text, "langpair": f"{source_lang}|{target_lang}"}
        try:
            resp = requests.get(self.BASE_URL, params=params, timeout=15)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            raise TranslationError(f"Network error: {e}")

        translated = data.get("responseData", {}).get("translatedText")
        status = data.get("responseStatus")
        if not translated or (status and int(status) >= 400):
            raise TranslationError("MyMemory returned no translation.")
        return translated


# ---------------------------------------------------------------------
# 2. Google Cloud Translation API
#    Docs: https://cloud.google.com/translate/docs/reference/rest
#    Requires: an API key with the Cloud Translation API enabled.
# ---------------------------------------------------------------------
class GoogleTranslateAPI:
    BASE_URL = "https://translation.googleapis.com/language/translate/v2"

    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.environ.get("GOOGLE_TRANSLATE_API_KEY")
        if not self.api_key:
            raise TranslationError(
                "Missing Google Translate API key. "
                "Set the GOOGLE_TRANSLATE_API_KEY environment variable."
            )

    def translate(self, text: str, source_lang: str, target_lang: str) -> str:
        params = {
            "key": self.api_key,
            "q": text,
            "source": source_lang,
            "target": target_lang,
            "format": "text",
        }
        try:
            resp = requests.post(self.BASE_URL, data=params, timeout=15)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            raise TranslationError(f"Network error: {e}")

        try:
            return data["data"]["translations"][0]["translatedText"]
        except (KeyError, IndexError):
            message = data.get("error", {}).get("message", "Unknown error")
            raise TranslationError(f"Google Translate error: {message}")


# ---------------------------------------------------------------------
# 3. Microsoft Translator (Azure Cognitive Services)
#    Docs: https://learn.microsoft.com/azure/ai-services/translator/
#    Requires: a subscription key and the resource's region.
# ---------------------------------------------------------------------
class MicrosoftTranslatorAPI:
    BASE_URL = "https://api.cognitive.microsofttranslator.com/translate"

    def __init__(self, api_key: str = None, region: str = None):
        self.api_key = api_key or os.environ.get("MICROSOFT_TRANSLATOR_KEY")
        self.region = region or os.environ.get("MICROSOFT_TRANSLATOR_REGION")
        if not self.api_key or not self.region:
            raise TranslationError(
                "Missing Microsoft Translator credentials. "
                "Set MICROSOFT_TRANSLATOR_KEY and MICROSOFT_TRANSLATOR_REGION."
            )

    def translate(self, text: str, source_lang: str, target_lang: str) -> str:
        headers = {
            "Ocp-Apim-Subscription-Key": self.api_key,
            "Ocp-Apim-Subscription-Region": self.region,
            "Content-Type": "application/json",
            "X-ClientTraceId": str(uuid.uuid4()),
        }
        params = {"api-version": "3.0", "from": source_lang, "to": target_lang}
        body = [{"text": text}]

        try:
            resp = requests.post(
                self.BASE_URL, params=params, headers=headers, json=body, timeout=15
            )
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            raise TranslationError(f"Network error: {e}")

        try:
            return data[0]["translations"][0]["text"]
        except (KeyError, IndexError, TypeError):
            raise TranslationError("Microsoft Translator returned no translation.")


# ---------------------------------------------------------------------
# Factory: pick a provider by name (defaults to the free MyMemory API)
# ---------------------------------------------------------------------
def get_translator(provider: str = None):
    """
    Returns a translator instance for the requested provider.
    Falls back to MyMemory (free, no key) if nothing is specified
    or if the requested provider's credentials are missing.
    """
    provider = (provider or os.environ.get("TRANSLATION_PROVIDER") or "mymemory").lower()

    if provider == "google":
        return GoogleTranslateAPI()
    elif provider == "microsoft":
        return MicrosoftTranslatorAPI()
    else:
        return MyMemoryTranslator()
